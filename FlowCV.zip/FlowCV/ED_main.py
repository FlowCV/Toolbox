"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module is the main file of the edge detection module.
"""

import cv2
import numpy as np
from matplotlib import pyplot as plt
from copy import deepcopy
from itertools import groupby

# FlowCV functions
import module_settings as mod
import ED_preprocessing as edpre
import ED_solver as edsol
import ED_postprocessing as edpos

def edmain(wb, db, ImFold, imlist, imlist_num):
    print "Edge Detection module running..."
    
    # Get the settings from xlsm file. 
    edsettings, flag_vld, edwspre, edwssol, edwspos = mod.get_edsettings(wb)

    if flag_vld == 1:
        EDImSub = wb.get_named_range('EDImSub').attr_text[wb.get_named_range('EDImSub').attr_text.index('!$')+1::]
        EDImPre = wb.get_named_range('EDImPre').attr_text[wb.get_named_range('EDImPre').attr_text.index('!$')+1::]
        
        endloop = len(imlist)
        if len(imlist) > 1 and edwspre[EDImPre].value == 'activated' and edwspre[EDImSub].value == 'activated':    # more than 1 image to be processed, preprocessing for edge detection is activates and background subtraction is active --> all good 
            endloop = len(imlist)-1
            flag_sub = 1
        elif len(imlist) == 1 and edwspre[EDImPre].value == 'activated' and edwspre[EDImSub].value == 'activated': # Background subtraction with only 1 image not possible!
            flag_sub = -1
        else: # no background subtraction selected
            flag_sub = 0
            
        b = 0
        for b in range(0,endloop,db):
            im1 = cv2.imread(ImFold + '/' + imlist[b],0)                       # read image into array,
            im = im1
            if 'pre' in edsettings:    
                print 'ED Image preprocessing running for image ', imlist_num[b], ' of ', len(imlist)
         
                im_pre = edpre.adj(ImFold, imlist, imlist_num, b, wb, edwspre, im, flag_sub)
                im = im_pre
                if flag_sub == 1:                                              # if background subtraction is selected, static image regions will be masked out
                   im = np.ma.masked_where(im < 200, im_pre)    
                
            # Conduct analysis (SOLVER).

            if 'sol' in edsettings:
                print 'ED Solver running for image ', imlist_num[b], ' of ', len(imlist)

                edges = edsol.calc(imlist_num, b, wb, edwssol, im, flag_sub)
                

            # Conduct analysis (POSTPROCESSING).

            if 'pos' in edsettings:
                print 'ED postprocessing running for image ', imlist_num[b], ' of ', len(imlist)

                EDPosMorph = wb.get_named_range('EDPosMorph').attr_text[wb.get_named_range('EDPosMorph').attr_text.index('!$')+1::]
                if edwspos[EDPosMorph].value == 'activated':                   # Perform image morpholoy operations (dilation and erosion) on detected edges
                   edges_eroded = edpos.morph(wb, edwspos, edges)
                   edges = edges_eroded
                
                # Extract contours vectors from edges array
                edges_copy = deepcopy(edges)                                   # findcontours is a destructive function we need to copy edges to not modify it with edges_copy
                contours, hierarchy = cv2.findContours(edges_copy, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)
                # Identify water surface contour
                cnts = sorted(contours, key = cv2.contourArea, reverse = True)[:1] # Contours are sorted by their length and only the longest one retained (after a proper image preprocessing, this one should be the water surface)
                cnts = np.vstack(cnts).squeeze()                               # reshape the water surface contour as an array with [x,2] shape
                contx = cnts[:,0]
                conty = cnts[:,1]
                # if the surface contour is detected by an upper and lower edge, the upper one will be regarded as the surface line and the lower values are skipped
                contx, conty = zip(*[next(g) for k, g in groupby(sorted(zip(contx, conty)), key = lambda x: x[0])]) 
                contx = np.asarray(contx)
                conty = np.asarray(conty)
                
                # Scale results from px to mm 
                scale, res_name, contymm, str_x, str_y = edpos.scl(imlist_num, b, wb, edwspos, edges, conty)
                
                # Export results
                if 'pos' in edsettings:
                
                    EDPosImBack = wb.get_named_range('EDPosImBack').attr_text[wb.get_named_range('EDPosImBack').attr_text.index('!$')+1::]
                    EDPosSurf = wb.get_named_range('EDPosSurf').attr_text[wb.get_named_range('EDPosSurf').attr_text.index('!$')+1::]
                    EDSaveTXT = wb.get_named_range('EDSaveTXT').attr_text[wb.get_named_range('EDSaveTXT').attr_text.index('!$')+1::]
                    if edwspos[EDPosImBack].value == 'yes' or edwspos[EDPosSurf].value == 'yes':      # plot figure
                       edpos.fig(ImFold,b,str_x, str_y,res_name,imlist_num,EDPosImBack,EDPosSurf,wb,edwspos,im1, scale, contours, contx, conty, contymm)
                    if edwspos[EDSaveTXT].value == 'yes':
                       edpos.txt(ImFold, res_name,contx,contymm)                                                                            # save ASCII file

            b = b+db
            pass

       

