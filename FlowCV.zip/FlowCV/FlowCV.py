"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This is the main file of the FlowCV toolbox.
"""

__author__ = "Daniel B. Bung and Daniel Valero"
__copyright__ = "Copyright 2017, FlowCV"
__credits__ = ["This toolbox is based on the libraries openCV, openpyxl, matplotlib, numpy, scipy and copy"]
__license__ = "GPLv.3"
__version__ = "1.0"
__maintainer__ = "Daniel B. Bung"
__email__ = "bung@fh-aachen.de"

# FlowCV functions
import OF_main as of
import ED_main as ed
import PG_main as pg
import functions_Excel as exf
import module_settings as mod
import functions_folders as ff

def main():
    
    print "FlowCV v. 1.0 Copyright (C) 2017  Daniel B. Bung & Daniel Valero"
    print "This program comes with ABSOLUTELY NO WARRANTY."
    print "This is free software, and you are welcome to redistribute it under certain conditions according to GNU v.3 license."
    print " "
    print "FlowCV running..."

    # Check that the Excel file (FlowCV_settings.xlsm) is available.
    flag, wb, wsmain = exf.check_xlsm()

    # open the Excel file, if available 
    if flag == 1:
        flag_img, flagpg, ImFold = ff.check_folders(wb, wsmain) # Check the image folder.
        flag_final = flag*flag_img                      # flag_final = 1, when everything is satisfactory.
        if flag_final == 1:
           settings, imlist, imlist_num = mod.get_mainsettings(wb, wsmain, ImFold) # Get the main settings for all modules.

           if 'ed' in settings:
               db = 1
               ed.edmain(wb, db, ImFold, imlist, imlist_num)
           if 'of' in settings:
               ProcSteps = wb.get_named_range('ProcSteps').attr_text[wb.get_named_range('ProcSteps').attr_text.index('!$')+1::]
               if wsmain[ProcSteps].value == '1-2, 2-3, 3-4':      # select image increment depending on processing steps
                   db = 1
               if wsmain[ProcSteps].value == '1-2, 3-4, 5-6':
                   db = 2
               if wsmain[ProcSteps].value == '':
                   print("No processing steps specified")               
               
               of.ofmain(wb, db, ImFold, imlist, imlist_num)
               
        if flagpg == 1:
           PGFold,PGImBase,PGImform,PGImNum,PGImResx, PGImResy, PGPartfrac, PGPRmean, PGPRstd,PGPImean, PGPIstd, PGustd, PGvstd, PGumean, PGvmean, CFL,PGTLx, PGTLy = pg.read_settings(wb)
           pg.generate(PGFold,PGImBase,PGImform,PGImNum,PGImResx, PGImResy, PGPartfrac, PGPRmean, PGPRstd,PGPImean, PGPIstd, PGustd, PGvstd, PGumean, PGvmean, CFL,PGTLx, PGTLy)
               
    print "Done!"
if __name__ == '__main__':
    main()
