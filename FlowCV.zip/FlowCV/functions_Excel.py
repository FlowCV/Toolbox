"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the necessary functions to access the Excel
interface based file.
"""

import glob
from openpyxl import load_workbook

def check_xlsm():
    """
    This function checks if the FlowCV_settings.xlsm file including the main sheet is in the FlowCV
    folder. Initially, flag = 0 and switches to 1 when xlsm and main sheet are found.
    """
    flag_xlsm = 0
    fname = glob.glob("FlowCV_settings.xlsm")

    if not fname:    # Checks if the list (filename) is empty
        print "FlowCV_settings.xlsm is not contained in the folder."
        print "FlowCV will not run."
        return flag_xlsm
    else:
        print "FlowCV_settings.xlsm file found."
        flag_xlsm = 1
        wsmain = []

        # FlowCV is in the folder. Check if the main spreadsheet is included.
        fname = "FlowCV_settings.xlsm"
        wb = load_workbook(fname, data_only=True) # Import Excel file with settings, ignore formulae in cells, if any
        ws_names = wb.get_sheet_names()
     
        if 'FlowCV_Main' not in ws_names:
            print "FlowCV main sheet  not found."
            print "FlowCV will not run."
            flag_wsmain = 0
            flag = flag_xlsm*flag_wsmain
            return flag

        else:   # The main sheet was found in the xlsm file.
            print "FlowCV main sheet is contained in the xlsm file."
            flag_wsmain = 1
            flag = flag_xlsm*flag_wsmain
            wsmain = wb.get_sheet_by_name('FlowCV_Main')
          
            return flag, wb, wsmain
