"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the necessary functions to perform the
postprocessing for edge detection.
"""
from matplotlib import pyplot as plt
import numpy as np
import cv2

def morph(wb, edwspos, edges):

    EDPosMorphKern = wb.get_named_range('EDPosMorphKern').attr_text[wb.get_named_range('EDPosMorphKern').attr_text.index('!$')+1::]
    EDPosMorphKern = edwspos[EDPosMorphKern].value
    if EDPosMorphKern is not None:
       kernel = np.ones((EDPosMorphKern,EDPosMorphKern), np.uint8)    # Kernel size for morphological operations (dilation + erosion --> closing of gaps)
       edges_dilated = cv2.dilate(edges, kernel, iterations=1)
       edges_eroded = cv2.erode(edges_dilated, kernel, iterations=1)
    else:
       print "Specifiy a correct Kernel size for Dilation & Erosion!"
       return    
   
    return edges_eroded        


def scl(imlist_num, b, wb, edwspos, edges, conty):
    
    res_name = 'im' + str(imlist_num[b]).zfill(4)

    EDFoVWidth = wb.get_named_range('EDFoVWidth').attr_text[wb.get_named_range('EDFoVWidth').attr_text.index('!$')+1::]
    EDPosyRef = wb.get_named_range('EDPosyRef').attr_text[wb.get_named_range('EDPosyRef').attr_text.index('!$')+1::]
    EDPosdRef = wb.get_named_range('EDPosdRef').attr_text[wb.get_named_range('EDPosdRef').attr_text.index('!$')+1::]
    if edwspos[EDFoVWidth].value >= 0 and edwspos[EDPosyRef].value >= 0 and edwspos[EDPosdRef].value >= 0:
       scale = float(edwspos[EDFoVWidth].value)/len(edges[1,:])        # Image scale mm/px
       str_x = 'Distance [mm]'
       str_y = 'Water depth [mm]'
       EDPosyRef = edwspos[EDPosyRef].value
       EDPosdRef = edwspos[EDPosdRef].value
    else:
       scale = 1
       str_x = 'Distance [px]'
       str_y = 'Water depth [px]'
       EDPosyRef = 0
       EDPosdRef = 0 
          
    conty_rel = conty - EDPosyRef                         # relative distance of the surface edge to given reference point
    contymm = conty_rel*scale                             # Scaling velocity field from [px] to [m/s], if applicable
    contymm = EDPosdRef - contymm                         # absolute water level in mm (if all scaling parameters were given in the spreadheet)

    return scale, res_name, contymm, str_x, str_y

def fig(ImFold,b,str_x,str_y,res_name,imlist_num,EDPosImBack,EDPosSurf,wb,edwspos,im1, scale, contours, contx, conty, contymm):
    plt.figure()
    if edwspos[EDPosImBack].value == 'yes':               # Show image in background
       plt.imshow(im1, cmap = 'gray'); plt.grid()
       if edwspos[EDPosSurf].value == 'yes':              # Plot detected surface line
            plt.plot(contx, conty); plt.xlabel("Distance [px]"); plt.ylabel("Distance [px]")
    if edwspos[EDPosImBack].value == 'no':                # Show no image in background
       if edwspos[EDPosSurf].value == 'yes':              # Plot detected surface line
          plt.plot(contx*scale, np.flipud(contymm));  
          plt.xlabel(str_x); plt.ylabel(str_y)
    plt.show(); plt.grid(); 

    title = 'Image ' + str(imlist_num[b])                 # Set figure title
    plt.suptitle(title, fontsize=12)

    EDSavePNG = wb.get_named_range('EDSavePNG').attr_text[wb.get_named_range('EDSavePNG').attr_text.index('!$')+1::]
    if edwspos[EDSavePNG].value == 'yes':
        EDSavePNGres = wb.get_named_range('EDSavePNGres').attr_text[wb.get_named_range('EDSavePNGres').attr_text.index('!$')+1::]
        if edwspos[EDSavePNGres].value > 0:
            plt.savefig(ImFold + '_results/' + res_name + '_ED.png', dpi=int(edwspos[EDSavePNGres].value))
        else:
            plt.savefig(ImFold + '_results/' + res_name + '_ED.png', dpi=150)
    EDSaveSVG = wb.get_named_range('EDSaveSVG').attr_text[wb.get_named_range('EDSaveSVG').attr_text.index('!$')+1::]
    if edwspos[EDSaveSVG].value == 'yes':
        plt.savefig(ImFold + '_results/' + res_name + '_ED.svg')
    return

def txt(ImFold, res_name,contx,contymm):
    np.savetxt(ImFold + '_results/' + res_name + '_x.txt', contx, fmt='%.4f')
    np.savetxt(ImFold + '_results/' + res_name + '_y.txt', contymm, fmt='%.4f')
    return

