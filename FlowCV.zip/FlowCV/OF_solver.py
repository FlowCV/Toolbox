"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the necessary functions to determine the
optical flow.
"""

import numpy as np
import cv2

def calc(imlist_num, b, wb, ofwssol,im1,im2):
    print 'Solver running for images ', imlist_num[b], ' and ', imlist_num[b+1]
    
    OFImPyr = wb.get_named_range('OFImPyr').attr_text[wb.get_named_range('OFImPyr').attr_text.index('!$')+1::]
    if ofwssol[OFImPyr].value == 'activated':                              # image pyramid technique is used
        OFImPyrScale = wb.get_named_range('OFImPyrScale').attr_text[wb.get_named_range('OFImPyrScale').attr_text.index('!$')+1::]
        OFImPyrLevels = wb.get_named_range('OFImPyrLevels').attr_text[wb.get_named_range('OFImPyrLevels').attr_text.index('!$')+1::]
        print "Image pyramid activated"
        OFImPyrScale = float(ofwssol[OFImPyrScale].value)                  # Scaling factor for reduced images between image pyramid levels
        OFImPyrLevels = int(ofwssol[OFImPyrLevels].value)                  # Number of image pyramid levels
    else: 
        OFImPyrLevels = 1; OFImPyrScale = 0.5                              # Image pyramid technique switched off by default
        print "Image pyramid not activated"
        
    OFmeth = wb.get_named_range('OFMeth').attr_text[wb.get_named_range('OFMeth').attr_text.index('!$')+1::]
    if ofwssol[OFmeth].value == 'Lucas-Kanade (1981)':                     # Local optical flow with Lucas-Kanade method
        GFTNumFeat = wb.get_named_range('GFTNumFeat').attr_text[wb.get_named_range('GFTNumFeat').attr_text.index('!$')+1::]
        GFTQualFeat = wb.get_named_range('GFTQualFeat').attr_text[wb.get_named_range('GFTQualFeat').attr_text.index('!$')+1::]
        GFTMinDist = wb.get_named_range('GFTMinDist').attr_text[wb.get_named_range('GFTMinDist').attr_text.index('!$')+1::]
        GFTBlkSize = wb.get_named_range('GFTBlkSize').attr_text[wb.get_named_range('GFTBlkSize').attr_text.index('!$')+1::]
        GFTNumFeat = int(ofwssol[GFTNumFeat].value)
        GFTQualFeat = float(ofwssol[GFTQualFeat].value)
        GFTMinDist = int(ofwssol[GFTMinDist].value)
        GFTBlkSize = int(ofwssol[GFTBlkSize].value)
        feature_params = dict(maxCorners = GFTNumFeat,                     # Maximum number of detected points (particles)
                              qualityLevel = GFTQualFeat,                  # 0 < value < 1... less particles found for higher values
                              minDistance = GFTMinDist,                    # More particles found for higher values
                              blockSize = GFTBlkSize)                      
        LKwindow = wb.get_named_range('LKwindow').attr_text[wb.get_named_range('LKwindow').attr_text.index('!$')+1::]
        LKnumit = wb.get_named_range('LKnumit').attr_text[wb.get_named_range('LKnumit').attr_text.index('!$')+1::]
        LKaccit = wb.get_named_range('LKaccit').attr_text[wb.get_named_range('LKaccit').attr_text.index('!$')+1::]
        LKwindow = int(ofwssol[LKwindow].value)
        LKnumit = int(ofwssol[LKnumit].value)
        LKaccit = float(ofwssol[LKaccit].value)/100                        # in percent
        lk_params = dict(winSize  = (LKwindow,LKwindow),                   # Size of the search window at each pyramid level
                         maxLevel = OFImPyrLevels - 1,                     # 0-based maximal pyramid level number; if set to 0, pyramids are not used (single level), if set to 1, two levels are used, and so on; if pyramids are passed to input then algorithm will use as many levels as pyramids have but no more than maxLevel
                         criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, LKnumit, LKaccit)) # parameter, specifying the termination criteria of the iterative search algorithm (after the specified maximum number of iterations criteria.maxCount or when the search window moves by less than criteria.epsilon
       
        points1 = cv2.goodFeaturesToTrack(im1, **feature_params)           # Determines strong corners on an image.
        points2, st, err = cv2.calcOpticalFlowPyrLK(im1, im2, points1, None, **lk_params) # Lucas-Kanade method (local tracking, sparse)
        points1_OFfound = points1[st==1]         # Extract those features in im1 for which the corresponding optical flow from im1 to im2 has been found
        points2_OFfound = points2[st==1]         # Extract those features in im2 for which the corresponding optical flow from im1 to im2 has been found
        #plt.scatter(points1_OFfound[:,0],points1_OFfound[:,1],s=5, c = 'r', marker = 'o') # check detected image features
        flowx_vec = points2_OFfound[:,0] - points1_OFfound[:,0]
        flowy_vec = points2_OFfound[:,1] - points1_OFfound[:,1]
        imsize = np.shape(im1)
        x = np.arange(0,imsize[1],1)
        y = np.arange(0,imsize[0],1)
        mesh_x, mesh_y = np.meshgrid(x,y)
        flowx = np.zeros_like(mesh_x, dtype=np.float32)
        flowy = np.zeros_like(mesh_y, dtype=np.float32)
        for vv in range(len(points1_OFfound[:,0])):
            flowx[int(points1_OFfound[vv,1]),int(points1_OFfound[vv,0])] = flowx_vec[vv]
            flowy[int(points1_OFfound[vv,1]),int(points1_OFfound[vv,0])] = -flowy_vec[vv]
        flowx[flowx==0] = np.nan
        flowy[flowy==0] = np.nan
        
    elif ofwssol[OFmeth].value == 'Farneback (2003)':                   # Dense optical flow using Farneback method
        FBwindow = wb.get_named_range('FBwindow').attr_text[wb.get_named_range('FBwindow').attr_text.index('!$')+1::]
        FBnumit = wb.get_named_range('FBnumit').attr_text[wb.get_named_range('FBnumit').attr_text.index('!$')+1::]
        FBsizenbh = wb.get_named_range('FBsizenbh').attr_text[wb.get_named_range('FBsizenbh').attr_text.index('!$')+1::]
        FBstdGauss = wb.get_named_range('FBstdGauss').attr_text[wb.get_named_range('FBstdGauss').attr_text.index('!$')+1::]
        FBwindow = int(ofwssol[FBwindow].value)
        FBnumit = int(ofwssol[FBnumit].value)
        FBsizenbh = int(ofwssol[FBsizenbh].value)
        FBstdGauss = float(ofwssol[FBstdGauss].value)
        flow = cv2.calcOpticalFlowFarneback(im1,im2, OFImPyrScale, OFImPyrLevels, FBwindow, FBnumit, FBsizenbh, FBstdGauss, 1, 0)    # Farnebeck method (local tracking, dense)
        flowx = flow[:,:,0]                                            # x-velocity 
        flowy = flow[:,:,1]                                            # y-velocity
        x = np.arange(0,len(im1[1,:]),1)                             
        y = np.arange(0,len(im1[:,1]),1)
    
    elif ofwssol[OFmeth].value == 'Horn & Schunck  (1981)':
        print "Horn & Schunck (1981) is no more supported"             # Horn & Schunck is no more included in CV2 
    
    else: 
        print "Please choose an Optical Flow method"
 

    flow_mag = np.sqrt(flowx*flowx + flowy*flowy)                      # velocity magnitude field
            
    return x, y, flowx, flowy, flow_mag
    