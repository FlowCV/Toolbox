"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the necessary functions to conduct the folder
management.
"""

import os
from openpyxl import load_workbook

def create_folder(foldername):
    """
    This function creates a folder, if not existing in the directory.
    """
    
    files = os.listdir('.')
    if foldername in files:             # Folder already exists! Let's empty it...
        subfiles = os.listdir('imgs_synthetic')
        for item in subfiles:           # Delete existing files to avoid later confusion.
            os.remove(foldername + '/' + item)
    else:                               # No folder with this name? Create it!
        os.makedirs(foldername)

    return


def check_folders(wb,wsmain):
    """
    This functions checks that the folder containing the images exists. flag = 0 if images
    folder was not found, flag = 1 otherwise. Name of the images folder is used to
    create the results folder (e.g.: img --> img_results).
    """

    # Check if the image folder is available
    flag = 0
    files = os.listdir('.')
    ImFold = wb.get_named_range('ImFold').attr_text[wb.get_named_range('ImFold').attr_text.index('!$')+1::]
    ImFold = wsmain[ImFold].value  
    
    if ImFold in files:                 
        print "Images folder found."
        flag = 1
    else:                               
        print "Images folder not found."
        print "FlowCV ED/OF will not run."
    
    PGMod = wb.get_named_range('PGMod').attr_text[wb.get_named_range('PGMod').attr_text.index('!$')+1::]
    if wsmain[PGMod].value == 'activated': 
        flagpg = 1
    
    if flag == 1:
        
        # Create the necessary subfolders, if necessary
        folder_pre = ImFold + '_pre'
        folder_results = ImFold + '_results'
        if folder_pre in files:
            print "Preprocessing folder already existing."
        else:
            os.makedirs(folder_pre)
            print "Preprocessing folder created."

        if folder_results in files:
            print "Results folder already existing."
        else:
            os.makedirs(folder_results)
            print "Results folder created."

    return flag, flagpg, ImFold
