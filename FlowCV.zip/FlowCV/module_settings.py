"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This function looks for the FlowCV_Main sheet in the FlowCV settings.xlsm file.
It is further checked for activated FlowCV modules.
"""

import os
import numpy as np


def get_mainsettings(wb, wsmain, ImFold):
        
        settings = []             
        imlist = []
        imlist_num = []
        a = 1
        
        ProcAll = wb.get_named_range('ProcAll').attr_text[wb.get_named_range('ProcAll').attr_text.index('!$')+1::]
        
        if wsmain[ProcAll].value == 'no':
            ImFirst = wb.get_named_range('ImFirst').attr_text[wb.get_named_range('ImFirst').attr_text.index('!$')+1::]
            ImLast = wb.get_named_range('ImLast').attr_text[wb.get_named_range('ImLast').attr_text.index('!$')+1::]
            ImIncr = wb.get_named_range('ImIncr').attr_text[wb.get_named_range('ImIncr').attr_text.index('!$')+1::]
            imlist_num =  np.arange(wsmain[ImFirst].value, wsmain[ImLast].value+0.001, wsmain[ImIncr].value) # generate an array with number of each image
            imlist_num  = imlist_num.astype(int)
        for file in os.listdir(ImFold):                 # find .png files in image folder
            if wsmain[ProcAll].value == 'yes':          # all images in image folder will be processed
                if file.endswith(".png"):
                   imlist_num.append(a)                 # generate an array with number of each image
                   imlist.append(file)
            if wsmain[ProcAll].value == 'no':           # only selected images will be processed
                if a in imlist_num:
                    if file.endswith(".png"):           # select images for specified image numbers (alphabetical order in subfolder assumed)
                        imlist.append(file)
            if str(file) != '.DS_Store':                # ignore hidden .DS_Store files (for MacOS)
               a = a+1

        # Check the enabled options.
        EDMod = wb.get_named_range('EDMod').attr_text[wb.get_named_range('EDMod').attr_text.index('!$')+1::]
        OFMod = wb.get_named_range('OFMod').attr_text[wb.get_named_range('OFMod').attr_text.index('!$')+1::]
        PGMod = wb.get_named_range('PGMod').attr_text[wb.get_named_range('PGMod').attr_text.index('!$')+1::]
        
        if wsmain[EDMod].value == 'activated':          # Edge detection module activated
            settings.append('ed')
        if wsmain[OFMod].value == 'activated':          # Optical flow module activated
            settings.append('of') 
        if wsmain[PGMod].value == 'activated':          # Optical flow module activated
            settings.append('pg')   
        return settings, imlist, imlist_num
        

def get_edsettings(wb):
    
    edsettings = []
    flag = 0
    edwspre = []
    edwssol = []
    edwspos = []

    # Check if all edge detection spreadsheets are available.

    ws_names = wb.get_sheet_names()
    if 'ED_Preprocessing' not in ws_names:
        print "ED Preprocessing worksheet not found."
        print "ED module will not run."
        return edsettings, flag

    elif 'ED_Solver' not in ws_names:
        print "Solver worksheet not found."
        print "ED module will not run."
        return edsettings, flag

    elif 'ED_Postprocessing' not in ws_names:
        print "ED Postprocessing worksheet not found."
        print "ED module will not run."
        return edsettings, flag

    else:   # All sheets are contained in the xlsm file.
        print "All necessary ED sheets are contained in the xlsm file."
        flag = 1
        edwspre = wb.get_sheet_by_name('ED_Preprocessing')
        edwssol = wb.get_sheet_by_name('ED_Solver')
        edwspos = wb.get_sheet_by_name('ED_Postprocessing')        
        
        # Check for enabled edge detection sub-modules.
        EDImPre = wb.get_named_range('EDImPre').attr_text[wb.get_named_range('EDImPre').attr_text.index('!$')+1::]
        EDSol = wb.get_named_range('EDSol').attr_text[wb.get_named_range('EDSol').attr_text.index('!$')+1::]
        EDDataPos = wb.get_named_range('EDDataPos').attr_text[wb.get_named_range('EDDataPos').attr_text.index('!$')+1::]
        if edwspre[EDImPre].value == 'activated':
            edsettings.append('pre')
        if edwssol[EDSol].value == 'activated':
            edsettings.append('sol')
        if edwspos[EDDataPos].value == 'activated':
            edsettings.append('pos')

        return edsettings, flag, edwspre, edwssol, edwspos        
                        

def get_ofsettings(wb):
    
    ofsettings = []
    flag = 0
    ofwspre = []
    ofwssol = []
    ofwspos = []

    # Check if all optical flow spreadsheets are available.

    ws_names = wb.get_sheet_names()
    # print('Sheet Names', sheet_names)
    if  'OF_Preprocessing' not in ws_names:
        print "OF Preprocessing worksheet not found."
        print "OF module will not run."
        return ofsettings, flag

    elif 'OF_Solver' not in ws_names:
        print "OF Solver worksheet not found."
        print "OF module will not run."
        return ofsettings, flag

    elif 'OF_Postprocessing' not in ws_names:
        print "OF Postprocessing worksheet not found."
        print "OF module will not run."
        return ofsettings, flag

    else:   # All sheets are contained in the xlsm file.
        print "All necessary OF sheets are contained in the xlsm file."
        flag = 1
        ofwspre = wb.get_sheet_by_name('OF_Preprocessing')
        ofwssol = wb.get_sheet_by_name('OF_Solver')
        ofwspos = wb.get_sheet_by_name('OF_Postprocessing')        
        
        # Check for enabled optical flow sub-modules.
        OFImPre = wb.get_named_range('OFImPre').attr_text[wb.get_named_range('OFImPre').attr_text.index('!$')+1::]
        OFSol = wb.get_named_range('OFSol').attr_text[wb.get_named_range('OFSol').attr_text.index('!$')+1::]
        OFDataPos = wb.get_named_range('OFDataPos').attr_text[wb.get_named_range('OFDataPos').attr_text.index('!$')+1::]
        if ofwspre[OFImPre].value == 'activated':
            ofsettings.append('pre')
        if ofwssol[OFSol].value == 'activated':
            ofsettings.append('sol')
        if ofwspos[OFDataPos].value == 'activated':
            ofsettings.append('pos')

        return ofsettings, flag, ofwspre, ofwssol, ofwspos


def get_pgsettings(wb):
    
    pgset = []

    # Check if all particle generation spreadsheets are available.

    ws_names = wb.get_sheet_names()
    # print('Sheet Names', sheet_names)
    if  'PG_Settings' not in ws_names:
        print "PG Settings worksheet not found."
        print "PG module will not run."
        return 

    else:   # All sheets are contained in the xlsm file.
        print "All necessary OF sheets are contained in the xlsm file."
        pgset = wb.get_sheet_by_name('PG_Settings')
    
        return pgset