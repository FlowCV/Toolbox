"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the synthetic particle image generator.
"""

import numpy as np
from PIL import Image

# FlowCV functions
import functions_folders as ff
import module_settings as mod

def read_settings(wb):
    
    pgset = mod.get_pgsettings(wb)
    
    # Default settings ---
    CFL = 0.25    # < 1 to avoid particles advected more than one pixel per
                  # iteration. dt is adjusted and a frame is saved whem
                  # sum(dt) = 1.

    # User settings ---
    PGFold = wb.get_named_range('PGFold').attr_text[wb.get_named_range('PGFold').attr_text.index('!$')+1::]
    PGFold = pgset[PGFold].value
    PGImBase = wb.get_named_range('PGImBase').attr_text[wb.get_named_range('PGImBase').attr_text.index('!$')+1::]
    PGImBase = pgset[PGImBase].value
    PGImform = wb.get_named_range('PGImform').attr_text[wb.get_named_range('PGImform').attr_text.index('!$')+1::]
    PGImform = pgset[PGImform].value

    # resolution
    PGImResx = wb.get_named_range('PGImResx').attr_text[wb.get_named_range('PGImResx').attr_text.index('!$')+1::]
    PGImResx = pgset[PGImResx].value    
    PGImResy = wb.get_named_range('PGImResy').attr_text[wb.get_named_range('PGImResy').attr_text.index('!$')+1::]
    PGImResy = pgset[PGImResy].value

    # Number of frames to be generated.
    PGImNum = wb.get_named_range('PGImNum').attr_text[wb.get_named_range('PGImNum').attr_text.index('!$')+1::]
    PGImNum = pgset[PGImNum].value

    # Velocity parameters
    PGumean = wb.get_named_range('PGumean').attr_text[wb.get_named_range('PGumean').attr_text.index('!$')+1::]
    PGumean = pgset[PGumean].value
    PGvmean = wb.get_named_range('PGvmean').attr_text[wb.get_named_range('PGvmean').attr_text.index('!$')+1::]
    PGvmean = pgset[PGvmean].value

    # Turbulence parameters
    PGustd = wb.get_named_range('PGustd').attr_text[wb.get_named_range('PGustd').attr_text.index('!$')+1::]
    PGustd = pgset[PGustd].value
    PGvstd = wb.get_named_range('PGvstd').attr_text[wb.get_named_range('PGvstd').attr_text.index('!$')+1::]
    PGvstd = pgset[PGvstd].value
    PGTLx = wb.get_named_range('PGTLx').attr_text[wb.get_named_range('PGTLx').attr_text.index('!$')+1::]
    PGTLx = pgset[PGTLx].value
    PGTLy = wb.get_named_range('PGTLy').attr_text[wb.get_named_range('PGTLy').attr_text.index('!$')+1::]
    PGTLy = pgset[PGTLy].value

    # Particles
    PGPartfrac = wb.get_named_range('PGPartfrac').attr_text[wb.get_named_range('PGPartfrac').attr_text.index('!$')+1::]
    PGPartfrac = pgset[PGPartfrac].value
    PGPRmean = wb.get_named_range('PGPRmean').attr_text[wb.get_named_range('PGPRmean').attr_text.index('!$')+1::]
    PGPRmean = pgset[PGPRmean].value
    PGPRstd = wb.get_named_range('PGPRstd').attr_text[wb.get_named_range('PGPRstd').attr_text.index('!$')+1::]
    PGPRstd = pgset[PGPRstd].value    

    # Light
    PGPImean = wb.get_named_range('PGPImean').attr_text[wb.get_named_range('PGPImean').attr_text.index('!$')+1::]
    PGPImean = pgset[PGPImean].value
    PGPIstd = wb.get_named_range('PGPIstd').attr_text[wb.get_named_range('PGPIstd').attr_text.index('!$')+1::]
    PGPIstd = pgset[PGPIstd].value

    return PGFold, PGImBase,PGImform,PGImNum,PGImResx, PGImResy, PGPartfrac, PGPRmean, PGPRstd,PGPImean, PGPIstd, PGustd, PGvstd, PGumean, PGvmean, CFL,PGTLx, PGTLy

def u_uniform(x, y, um, ufluc):
    """
    Uniform velocity distribution.
    """
    
    return um + ufluc


def draw_particle(frame, i, j, r):
    """
    This function draws a circle with center 'i', 'j' and radius 'r'.
    It takes as an input a frame, modifies it and returns it with the
    new particle.
    """

    rmax = int(r)
    i_int = i.astype(int)
    j_int = j.astype(int)

    [res_i, res_j] = np.shape(frame)

    ilim = range(np.max([i_int-rmax-1, 0]), np.min([i_int+rmax+1, res_i]))
    jlim = range(np.max([j_int-rmax-1, 0]), np.min([j_int+rmax+1, res_j]))

    for ii in ilim:
        for jj in jlim:

            ri = np.sqrt((ii-i)**2 + (jj-j)**2)

            if ri < rmax:
                frame[ii, jj] = 1.0
            elif ri < (rmax + 1):
                frame[ii, jj] = np.max(ri - rmax, 0)    # it can contains smth.

    return frame


def shadow_particles(frame, light):
    """
    This function adds a shadow effect provided the light and a frame with the
    particles drawn (fp.draw_particle) ranging values of 0 - 1. It returns a
    frame in the scale of 0 - 255.
    """

    [res_i, res_j] = np.shape(frame)
    m = 0
    for i in range(0, res_i):
        for j in range(0, res_j):

            if light[m] > 255:
                light[m] = 255
            elif light[m] < 0:
                light[m] = 0

            frame[i, j] = frame[i, j]*light[m]
            m = m + 1

    return frame



def rK4_2D(a, b, fa, fb, hs, um, ufluc, vm, vfluc):
    """
    This function performs a Runge-Kutta 4th order for a 2D problem.
    'fa' and 'fb' are functions.
    """
    a1 = fa(a, b, um, ufluc)*hs
    b1 = fb(a, b, vm, vfluc)*hs

    ak = a + a1*0.5
    bk = b + b1*0.5

    a2 = fa(ak, bk, um, ufluc)*hs
    b2 = fb(ak, bk, vm, vfluc)*hs

    ak = a + a2*0.5
    bk = b + b2*0.5

    a3 = fa(ak, bk, um, ufluc)*hs
    b3 = fb(ak, bk, vm, vfluc)*hs

    ak = a + a3
    bk = b + b3

    a4 = fa(ak, bk, um, ufluc)*hs
    b4 = fb(ak, bk, vm, vfluc)*hs

    a = a + (a1 + 2*(a2 + a3) + a4)/6
    b = b + (b1 + 2*(b2 + b3) + b4)/6

    return a, b


velocity_x = u_uniform    # velocity profile
velocity_y = u_uniform    # velocity profile

def generate(PGFold,PGImBase,PGImform,PGImNum,PGImResx, PGImResy, PGPartfrac, PGPRmean, PGPRstd,PGPImean, PGPIstd, PGustd, PGvstd, PGumean, PGvmean, CFL,PGTLx, PGTLy):
    """
    Main function. Responsible of the particles generation.
    """
    
    frame_old = np.zeros((PGImResx, PGImResy))
    #light = np.ones((PGImResy, PGImResx))
    ff.create_folder(PGFold)

    # Frame 0 --- Initialize random particles
    npar = int(PGPartfrac*PGImResx*PGImResy/(np.pi*PGPRmean*PGPRmean))
    
    sample_x = np.random.uniform(0, PGImResx, npar)
    sample_x_new = np.zeros(npar)
    
    sample_y = np.random.uniform(0, PGImResy, npar)
    sample_y_new = np.zeros(npar)
    
    sample_r = np.abs(np.random.normal(PGPRmean, PGPRstd, npar))
    sample_light = np.random.normal(PGPImean, PGPIstd, PGImResx*PGImResy)

    for n in range(0, npar):

        [i, j, r] = [sample_x[n], sample_y[n], sample_r[n]]
        frame_old = draw_particle(frame_old, i, j, r)        # Draws circle.

    frame_old = shadow_particles(frame_old, sample_light)    # Applies a shadow

    file_name = "%06d" % 1
    route = PGFold + '/' + PGImBase + file_name + '.' + PGImform

    # Save the first image
    IM1 = Image.fromarray(np.uint8(np.transpose(frame_old)))
    IM1.save(route, PGImform)
    print "Saving...", route
    # Save the particles position in a *.txt file
    fname_x = PGFold + '/' + PGImBase + file_name + '_x.txt'
    np.savetxt(fname_x, sample_x)
    fname_y = PGFold + '/' + PGImBase + file_name + '_y.txt'
    np.savetxt(fname_y, sample_y)

    # Generate the fluctuation for each particle.
    ufluct_0 = PGustd*np.random.normal(0, 1, npar)
    vfluct_0 = PGvstd*np.random.normal(0, 1, npar)

    # Generate PGImNum frames
    for k in range(1, PGImNum):
        frame_old = np.zeros((PGImResx, PGImResy))


        for i in range(0, npar):

            ti = 0.0
            # Initialize dt
        
            dt = CFL*1.0/(PGumean + 3.5*PGustd)                # To make sure we don't overpass umax

            while ti < 1.0:
                
                # Eq. (10) of Bung and Valero (2017):
                ufluct_0[i] = (ufluct_0[i] - ufluct_0[i]*dt/PGTLx +
                          np.sqrt(2*PGustd*PGustd*dt/PGTLx)*np.random.normal(0, 1, 1))

                vfluct_0[i] = (vfluct_0[i] - vfluct_0[i]*dt/PGTLy +
                          np.sqrt(2*PGvstd*PGvstd*dt/PGTLy)*np.random.normal(0, 1, 1))


                sample_x_new[i], sample_y_new[i] = rK4_2D(sample_x[i],
                                                             sample_y[i],
                                                             velocity_x,
                                                             velocity_y, dt,
                                                             PGumean, ufluct_0[i],
                                                             PGvmean, vfluct_0[i])


                ti = ti + dt

                umax = np.max(np.max(np.abs(velocity_x(sample_x[i], sample_y[i], PGumean, PGustd))))
                vmax = np.max(np.max(np.abs(velocity_y(sample_x[i], sample_y[i], PGvmean, PGvstd))))
                dt = CFL/np.max([umax+0.1, vmax+0.1])    # CFL using u, v max;
                dt = np.min([1.0 - ti, dt])              # To ensure we don't pass 1.0 frames

                # Check if one particle went out... and insert it again at the opposite boundary.

                if sample_x_new[i] > PGImResx:
                    sample_x_new[i] = sample_x_new[i] - PGImResx
                elif sample_x_new[i] < 0:
                    sample_x_new[i] = sample_x_new[i] + PGImResx

                if sample_y_new[i] > PGImResy:
                    sample_y_new[i] = sample_y_new[i] - PGImResy
                elif sample_y_new[i] < 0:
                    sample_y_new[i] = sample_y_new[i] + PGImResy
                
                [sample_x[i], sample_y[i]] = [sample_x_new[i], sample_y_new[i]]

            # Reallocate the new particles.
            frame_old = draw_particle(frame_old, sample_x_new[i],
                                     sample_y_new[i], sample_r[i])

            # Get the new frame and save it.
            [sample_x[i], sample_y[i]] = [sample_x_new[i], sample_y_new[i]]

        frame_old = shadow_particles(frame_old, sample_light)

        file_name = "%06d" % (k+1)
        route = PGFold + '/' + PGImBase + file_name + '.' + PGImform
        print "Saving...", route
        IM1 = Image.fromarray(np.uint8(np.transpose(frame_old)))
        IM1.save(route, PGImform)
        fname_x = PGFold + '/' + PGImBase + file_name + '_x.txt'
        np.savetxt(fname_x, sample_x)
        fname_y = PGFold + '/' + PGImBase + file_name + '_y.txt'
        np.savetxt(fname_y, sample_y)

    return
