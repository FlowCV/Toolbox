"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module is the main file for optical flow determination.
"""

import cv2
import numpy as np

# FlowCV functions
import module_settings as mod
import OF_preprocessing as ofpre
import OF_solver as ofsol
import OF_postprocessing as ofpos

def ofmain(wb, db, ImFold, imlist, imlist_num):
    print "Optical Flow module running..."
    
    # Check that the xlsm file is valid and get the settings. 
    ofsettings, flag_vld, ofwspre, ofwssol, ofwspos = mod.get_ofsettings(wb)
    
    if flag_vld == 1:

        b = 0
        c = 0
        cmax = (len(imlist)-1)/db
        OFAveraging = wb.get_named_range('OFAveraging').attr_text[wb.get_named_range('OFAveraging').attr_text.index('!$')+1::]
        OFAveraging = ofwspos[OFAveraging].value
        for b in range(0,len(imlist)-1,db):
            im1 = cv2.imread(ImFold + '/' + imlist[b],0)                    # read first image into array,
            im2 = cv2.imread(ImFold + '/' + imlist[b+1],0)                  # read second image into array,
            if OFAveraging == 'mean' or OFAveraging == 'median':            # Mean or median averaging activated
               if b == 0:                                                   # setting up arrays summing all single results (for averaging later)
                  flowx_all = np.zeros((im1.shape[0],im1.shape[1],cmax))    
                  flowx_all[flowx_all==0] = np.nan
                  flowy_all = np.zeros((im1.shape[0],im1.shape[1],cmax))    
                  flowy_all[flowy_all==0] = np.nan                  
                  flow_mag_all = np.zeros((im1.shape[0],im1.shape[1],cmax)) 
                  flow_mag_all[flow_mag_all==0] = np.nan
                  
            # Conduct analysis (PREPROCESSING).
            if 'pre' in ofsettings:
                im1_pre, im2_pre = ofpre.adj(ImFold, imlist, imlist_num, b, wb, ofwspre, im1, im2)
                im1 = im1_pre
                im2 = im2_pre

            # Conduct analysis (SOLVER).
            if 'sol' in ofsettings:
                x, y, flowx, flowy, flow_mag = ofsol.calc(imlist_num, b, wb, ofwssol, im1, im2)
                
                OFMinVelMagn = wb.get_named_range('OFMinVelMagn').attr_text[wb.get_named_range('OFMinVelMagn').attr_text.index('!$')+1::]
                OFMinVelMagn = ofwspos[OFMinVelMagn].value 
                if OFMinVelMagn is not None:
                   flowx = np.ma.masked_where(flow_mag < OFMinVelMagn, flowx)              # mask out regions with low x-velocity (threshold value may be changed)
                   flowy = np.ma.masked_where(flow_mag < OFMinVelMagn, flowy)              # mask out regions with low y-velocity (threshold value may be changed)   
                   flow_mag = np.ma.masked_where(flow_mag < OFMinVelMagn, flow_mag)        # mask out regions with low velocity magn. (threshold value may be changed)
                   
                OFMaxVelMagn = wb.get_named_range('OFMaxVelMagn').attr_text[wb.get_named_range('OFMaxVelMagn').attr_text.index('!$')+1::]
                OFMaxVelMagn = ofwspos[OFMaxVelMagn].value 
                if OFMaxVelMagn is not None:
                   flowx = np.ma.masked_where(flow_mag > OFMaxVelMagn, flowx)              # mask out regions with high x-velocity (threshold value may be changed)
                   flowy = np.ma.masked_where(flow_mag > OFMaxVelMagn, flowy)              # mask out regions with high y-velocity (threshold value may be changed)   
                   flow_mag = np.ma.masked_where(flow_mag > OFMaxVelMagn, flow_mag)        # mask out regions with high velocity magn. (threshold value may be changed)  

                if OFAveraging == 'mean' or OFAveraging == 'median':
                   flowx_all[:,:,c] = flowx
                   flowy_all[:,:,c] = flowy
                   flow_mag_all[:,:,c] = flow_mag
                   c = c+1

            # Conduct analysis (POSTPROCESSING).
            if 'pos' in ofsettings:
                scale, deltat, res_name, flowx, flowy, flow_mag, str_mag = ofpos.scl(imlist_num, b, wb, ofwspos,flowx,flowy,flow_mag)
                
                OFPosImBack = wb.get_named_range('OFPosImBack').attr_text[wb.get_named_range('OFPosImBack').attr_text.index('!$')+1::]
                OFPosVelMagn = wb.get_named_range('OFPosVelMagn').attr_text[wb.get_named_range('OFPosVelMagn').attr_text.index('!$')+1::]
                OFPosVelVec = wb.get_named_range('OFPosVelVec').attr_text[wb.get_named_range('OFPosVelVec').attr_text.index('!$')+1::]
                OFSaveTXT = wb.get_named_range('OFSaveTXT').attr_text[wb.get_named_range('OFSaveTXT').attr_text.index('!$')+1::]
                if ofwspos[OFPosImBack].value == 'yes' or ofwspos[OFPosVelMagn].value == 'yes' or ofwspos[OFPosVelVec].value == 'yes': # save figure
                   ofpos.fig(ImFold,b,str_mag,res_name,imlist_num,OFPosImBack,OFPosVelMagn,OFPosVelVec,wb,ofwspos,im1,flowx,flowy,flow_mag)
                if ofwspos[OFSaveTXT].value == 'yes':
                   ofpos.txt(ImFold, res_name, flowx,flowy,flow_mag)                                      # save ASCII file

            b = b+db

            pass

        if 'pos' in ofsettings and OFAveraging != 'no':                                                   # Averaging activated
            flowx_all = flowx_all*scale/deltat
            flowy_all = flowy_all*scale/deltat
            flow_mag_all = flow_mag_all*scale/deltat
            if OFAveraging == 'mean':                                                                     # Mean averaging of velocity fields
                print 'OF Data postprocessing running for mean results'
                flowx_mean = np.nanmean(flowx_all, axis = 2)
                flowy_mean = np.nanmean(flowy_all, axis = 2)
                flow_mag_mean = np.nanmean(flow_mag_all, axis = 2)
                if OFMinVelMagn is not None:
                   flowx_mean = np.ma.masked_where(flow_mag_mean < OFMinVelMagn, flowx_mean)              # mask out regions with low x-velocity (threshold value may be changed)
                   flowy_mean = np.ma.masked_where(flow_mag_mean < OFMinVelMagn, flowy_mean)              # mask out regions with low y-velocity (threshold value may be changed)
                   flow_mag_mean = np.ma.masked_where(flow_mag_mean < OFMinVelMagn, flow_mag_mean)        # mask out regions with low velocity magn. (threshold value may be changed)
                if OFMaxVelMagn is not None:
                   flowx_mean = np.ma.masked_where(flow_mag_mean > OFMaxVelMagn, flowx_mean)              # mask out regions with high x-velocity (threshold value may be changed)
                   flowy_mean = np.ma.masked_where(flow_mag_mean > OFMaxVelMagn, flowy_mean)              # mask out regions with high y-velocity (threshold value may be changed)
                   flow_mag_mean = np.ma.masked_where(flow_mag_mean > OFMaxVelMagn, flow_mag_mean)        # mask out regions with high velocity magn. (threshold value may be changed)                
                b = -1
                res_name = 'mean'
                if ofwspos[OFPosImBack].value == 'yes' or ofwspos[OFPosVelMagn].value == 'yes' or ofwspos[OFPosVelVec].value == 'yes':
                    ofpos.fig(ImFold, b, str_mag,res_name,imlist_num,OFPosImBack,OFPosVelMagn,OFPosVelVec,wb,ofwspos,im1, flowx_mean, flowy_mean, flow_mag_mean)
                if ofwspos[OFSaveTXT].value == 'yes':
                    ofpos.txt(ImFold, res_name, flowx_mean,flowy_mean,flow_mag_mean)
            if OFAveraging == 'median':                                                                   # Median averaging of velocity fields
                print 'OF Data postprocessing running for median results'
                flowx_median = np.nanmedian(flowx_all, axis = 2)
                flowy_median = np.nanmedian(flowy_all, axis = 2)
                flow_mag_median = np.nanmedian(flow_mag_all, axis = 2)
                if OFMinVelMagn is not None:
                   flowx_median = np.ma.masked_where(flow_mag_median < OFMinVelMagn, flowx_median)        # mask out regions with low x-velocity (threshold value may be changed)
                   flowy_median = np.ma.masked_where(flow_mag_median < OFMinVelMagn, flowy_median)        # mask out regions with low y-velocity (threshold value may be changed)
                   flow_mag_median = np.ma.masked_where(flow_mag_median < OFMinVelMagn, flow_mag_median)  # mask out regions with low velocity magn. (threshold value may be changed)
                if OFMaxVelMagn is not None:
                   flowx_mean = np.ma.masked_where(flow_mag_mean > OFMaxVelMagn, flowx_mean)              # mask out regions with high x-velocity (threshold value may be changed)
                   flowy_mean = np.ma.masked_where(flow_mag_mean > OFMaxVelMagn, flowy_mean)              # mask out regions with high y-velocity (threshold value may be changed)
                   flow_mag_mean = np.ma.masked_where(flow_mag_mean > OFMaxVelMagn, flow_mag_mean)        # mask out regions with high velocity magn. (threshold value may be changed)
                b = -2
                res_name = 'median'
                if ofwspos[OFPosImBack].value == 'yes' or ofwspos[OFPosVelMagn].value == 'yes' or ofwspos[OFPosVelVec].value == 'yes':
                    ofpos.fig(ImFold, b, str_mag,res_name,imlist_num,OFPosImBack,OFPosVelMagn,OFPosVelVec,wb,ofwspos,im1, flowx_median, flowy_median, flow_mag_median)
                if ofwspos[OFSaveTXT].value == 'yes':
                    ofpos.txt(ImFold, res_name, flowx_median,flowy_median,flow_mag_median)

                ofpos.divergence(x,y,flowx_median,flowy_median)                                           # Determine flowfield divergence

