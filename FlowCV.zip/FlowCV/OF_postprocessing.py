"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the necessary functions to perform the
postprocessing for optical flow results.
"""

from matplotlib import pyplot as plt
import numpy as np

def scl(imlist_num, b, wb, ofwspos,flowx,flowy,flow_mag):
    print 'OF Data postprocessing running for images ', imlist_num[b], ' and ', imlist_num[b+1]

    if b >= 0:
       res_name = 'im' + str(imlist_num[b]).zfill(4) + 'and' + str(imlist_num[b+1]).zfill(4)

    flag_scale = 0
    flag_time = 0
    FoVWidth = wb.get_named_range('OFFoVWidth').attr_text[wb.get_named_range('OFFoVWidth').attr_text.index('!$')+1::]
    if ofwspos[FoVWidth].value >= 0:
       scale = (float(ofwspos[FoVWidth].value)/1000)/len(flowx[1,:])   # Image scale m/px
    else:
       scale = 1
       flag_scale= 1
    TimeIncr = wb.get_named_range('OFTimeIncr').attr_text[wb.get_named_range('OFTimeIncr').attr_text.index('!$')+1::]
    if ofwspos[TimeIncr].value >= 0:
       deltat = float(ofwspos[TimeIncr].value)/1000                    # Delta t in s
    else:
       deltat = 1
       flag_time = 1

    if flag_scale*flag_time ==1:                                       # flag_scale = 1 only if no scale and Delta t has been specified
       str_mag = 'Pixel Shift [px]'
    else:
       str_mag = 'Velocity [m/s]'

    # Scaling velocity field from [px] to [m/s], if applicable
    flowx = flowx*scale/deltat                                         
    flowy = flowy*scale/deltat                                         
    flow_mag = flow_mag*scale/deltat                                   

    return scale, deltat, res_name, flowx, flowy, flow_mag, str_mag

def fig(ImFold, b, str_mag, res_name, imlist_num, OFPosImBack, OFPosVelMagn, OFPosVelVec, wb, ofwspos, im1, flowx, flowy, flow_mag):
    plt.figure()
    if ofwspos[OFPosImBack].value == 'yes':                           # show first image in background
       plt.imshow(im1, cmap = 'gray'); plt.grid()
       if ofwspos[OFPosVelMagn].value == 'yes':                       # plot velocity magnitude
            plt.pcolor(flow_mag); cb = plt.colorbar(); cb.ax.set_ylabel(str_mag); #plt.clim(0,5);
       if ofwspos[OFPosVelVec].value == 'yes':                        # plot velocity vextors
            plt.quiver(flowx, flowy)
    if ofwspos[OFPosImBack].value == 'no':                            # no image in background
       if ofwspos[OFPosVelMagn].value == 'yes':                       # plot velocity magnitude
          plt.pcolor(np.flipud(flow_mag)); cb = plt.colorbar(); cb.ax.set_ylabel(str_mag); 
       if ofwspos[OFPosVelVec].value == 'yes':                        # plot velocity vextors
          plt.quiver(np.flipud(flowx), np.flipud(flowy))
    plt.show(); plt.grid();

    # set figure title
    if b == -1:
       title = 'Mean result'   
    elif b == -2:
       title = 'Median result' 
    else:
       title = 'Images ' + str(imlist_num[b]) + ' and ' + str(imlist_num[b+1]) # set figure title
    plt.suptitle(title, fontsize=12)

    OFSavePNG = wb.get_named_range('OFSavePNG').attr_text[wb.get_named_range('OFSavePNG').attr_text.index('!$')+1::]
    if ofwspos[OFSavePNG].value == 'yes': # save velocity plots to .png files
        OFSavePNGres = wb.get_named_range('OFSavePNGres').attr_text[wb.get_named_range('OFSavePNGres').attr_text.index('!$')+1::]
        if ofwspos[OFSavePNGres].value > 0:
            plt.savefig(ImFold + '_results/' + res_name + '.png', dpi=int(ofwspos[OFSavePNGres].value))
        else:
            plt.savefig(ImFold + '_results/' + res_name + '.png', dpi=150)
    OFSaveSVG = wb.get_named_range('OFSaveSVG').attr_text[wb.get_named_range('OFSaveSVG').attr_text.index('!$')+1::]
    if ofwspos[OFSaveSVG].value == 'yes':  # save velocity plots to .svg files
        plt.savefig(ImFold + '_results/' + res_name + '.svg')
    return

def txt(ImFold, res_name, flowx,flowy,flow_mag): # save velocity fields to ASCII files
    np.savetxt(ImFold + '_results/' + res_name + '_vx.txt', np.flipud(flowx), fmt='%.4f')
    np.savetxt(ImFold + '_results/' + res_name + '_vy.txt', np.flipud(flowy), fmt='%.4f')
    np.savetxt(ImFold + '_results/' + res_name + '_vmag.txt', np.flipud(flow_mag), fmt='%.4f')
    return


def divergence(x,y,flowx,flowy): # plot divergence field
    xgrid, ygrid = np.meshgrid(x, y)
    div = (np.diff(flowx,axis=1)/np.diff(xgrid,axis=1))[:-1,:] + (np.diff(flowy,axis=0)/np.diff(ygrid,axis=0))[:,:-1]
    plt.figure(); plt.pcolormesh(xgrid, ygrid, div, vmin=-0.5, vmax=0.5); plt.colorbar(); plt.show()
    return
