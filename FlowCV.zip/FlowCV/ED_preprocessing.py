"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the necessary functions to perform the
edge detection preprocessing.
"""

from scipy import signal
import cv2
from matplotlib import pyplot as plt
import numpy as np

def adj(ImFold, imlist, imlist_num, b, wb, edwspre, im, flag_sub):
    
    if flag_sub == 1:                                              # Background subtraction activated and more than 1 image being processed
       im2 = cv2.imread(ImFold + '/' + imlist[b+1],0)              # read second image into array, will be needed for background subtraction only in case of single frame processing
       im = cv2.subtract(im, im2)
       edimsubthres = wb.get_named_range('EDImSubThres').attr_text[wb.get_named_range('EDImSubThres').attr_text.index('!$')+1::]
       edimsubthres = int(edwspre[edimsubthres].value)
       if edimsubthres is not None and edimsubthres > 1 and  edimsubthres < 255:
          im[im < edimsubthres] = 0   
       else:
          print "No thresholding for background subtraction performed! Please specifiy a correct pixel intensity value!"

    elif flag_sub == -1:
        print 'At least 2 images are required for Background Subtraction! Edge Detection module stops running!'
        return   # FlowCV is stopped
        
    im_pre = im
    
    edimgamma = wb.get_named_range('EDImGamma').attr_text[wb.get_named_range('EDImGamma').attr_text.index('!$')+1::]
    edmorph = wb.get_named_range('EDMorph').attr_text[wb.get_named_range('EDMorph').attr_text.index('!$')+1::]
    edkernmorph = wb.get_named_range('EDKernMorph').attr_text[wb.get_named_range('EDKernMorph').attr_text.index('!$')+1::]
    edhisteq = wb.get_named_range('EDHistEq').attr_text[wb.get_named_range('EDHistEq').attr_text.index('!$')+1::]
    edimblur = wb.get_named_range('EDImBlur').attr_text[wb.get_named_range('EDImBlur').attr_text.index('!$')+1::]
    edimbin = wb.get_named_range('EDImBin').attr_text[wb.get_named_range('EDImBin').attr_text.index('!$')+1::]
    
    gamma = edwspre[edimgamma].value
    edkernmorph = int(edwspre[edkernmorph].value)
    if gamma is not None or gamma == 1:                               # Perform gamma correction
       gamma_table = np.array([((i / 255.0) ** (1.0/gamma)) * 255     # Set up pixel intensity scaling table
		for i in np.arange(0, 256)]).astype("uint8")
       im_pre = cv2.LUT(im_pre, gamma_table)                          # Scale pixel intensities
       if edwspre[edmorph].value == 'activated':
          if edkernmorph is not None:
             kernel = np.ones((edkernmorph,edkernmorph), np.uint8)    # Kernel size for morphological operations (dilation + erosion --> closing of gaps)
             im_pre_dilation = cv2.dilate(im_pre, kernel, iterations=1)
             im_pre_erosion = cv2.erode(im_pre_dilation, kernel, iterations=1)
             im_pre = im_pre_erosion
          else:
             print "Specifiy a correct Kernel size for Dilation & Erosion!"
             return      
              
    if edwspre[edhisteq].value == 'Standard':                         # Standard histogram equalization
       im_pre = cv2.equalizeHist(im_pre) 
    elif edwspre[edhisteq].value == 'CLAHE':                          # Contrast Limited Adaptive Histogram Equalization
       clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
       im_pre = clahe.apply(im_pre) 
    if edwspre[edimblur].value == 'Gaussian':                         # Gaussian blurring, filtsize is size of the filter window (should be odd!)
       edfiltsize = wb.get_named_range('EDFiltWinSizeBlur').attr_text[wb.get_named_range('EDFiltWinSizeBlur').attr_text.index('!$')+1::]
       edfiltsize = int(edwspre[edfiltsize].value)     
       im_pre = cv2.GaussianBlur(im_pre, (edfiltsize, edfiltsize), 0) 
    elif edwspre[edimblur].value == 'Wiener':                         # Wiener Filtering, filtsize is size of the filter window (should be odd!)
       edfiltsize = wb.get_named_range('EDFiltWinSizeBlur').attr_text[wb.get_named_range('EDFiltWinSizeBlur').attr_text.index('!$')+1::]
       edfiltsize = int(edwspre[edfiltsize].value)
       im_pre = signal.wiener(im_pre, mysize = edfiltsize) 
    elif edwspre[edimblur].value == 'Bilateral':                      # Bilateral filter
       edfiltsize = wb.get_named_range('EDFiltWinSizeBlur').attr_text[wb.get_named_range('EDFiltWinSizeBlur').attr_text.index('!$')+1::]
       edfiltsize = int(edwspre[edfiltsize].value)    
       edsigmacol = wb.get_named_range('EDSigmaCol').attr_text[wb.get_named_range('EDSigmaCol').attr_text.index('!$')+1::]
       edsigmacol = int(edwspre[edsigmacol].value) 
       edsigmasp = wb.get_named_range('EDSigmaSp').attr_text[wb.get_named_range('EDSigmaSp').attr_text.index('!$')+1::]
       edsigmasp = int(edwspre[edsigmasp].value) 
       im_pre = cv2.bilateralFilter(im_pre, edfiltsize, edsigmacol, edsigmasp);
    if edwspre[edimbin].value == 'activated':                         # Image binarization
       ret2,im_pre = cv2.threshold(im_pre,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU) # Automatic selection of threshold values by Otsus binarization
       
    str1 = imlist[b]
    cv2.imwrite(ImFold+'_pre/' + str1[0:-4] + '_ED_pre.png', im_pre)   # Write preprocessed image 1 to created subfolder

    return im_pre