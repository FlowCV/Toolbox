"""
FlowCV v. 1.0
Application of Computer Vision methods to hydraulic engineering problems
Copyright (C) 2017  
________________________________________________________________________
                 Daniel B. Bung & Daniel Valero
      bung@fh-aachen.de               valero@fh-aachen.de
      
                Hydraulic Engineering Section
           Aachen University of Applied Sciences
            Bayernallee 9, 52066 Aachen/Germany
________________________________________________________________________

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
________________________________________________________________________
This module provides FlowCV with the necessary functions to perform the
preprocessing for optical flow.
"""

from scipy import signal
import cv2


def adj(ImFold, imlist, imlist_num, b, wb, ofwspre, im1, im2):
    print 'OF Image preprocessing running for images ', imlist_num[b], ' and ', imlist_num[b+1]
    
    im1_pre = im1
    im2_pre = im2
    ofhisteq = wb.get_named_range('OFHistEq').attr_text[wb.get_named_range('OFHistEq').attr_text.index('!$')+1::]
    ofimblur = wb.get_named_range('OFImBlur').attr_text[wb.get_named_range('OFImBlur').attr_text.index('!$')+1::]
    if ofwspre[ofhisteq].value == 'Standard':                            # Standard histogram equalization
       im1_pre = cv2.equalizeHist(im1_pre) 
       im2_pre = cv2.equalizeHist(im2_pre) 
    elif ofwspre[ofhisteq].value == 'CLAHE':                             # Contrast Limited Adaptive Histogram Equalization
       clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
       im1_pre = clahe.apply(im1_pre) 
       im2_pre = clahe.apply(im2_pre) 
    if ofwspre[ofimblur].value == 'Gaussian':
       offiltsize = wb.get_named_range('OFFiltWinSizeBlur').attr_text[wb.get_named_range('OFFiltWinSizeBlur').attr_text.index('!$')+1::]
       offiltsize = int(ofwspre[offiltsize].value)     
       im1_pre = cv2.GaussianBlur(im1_pre, (offiltsize, offiltsize), 0)  # Gaussian blurring, filtsize is size of the filter window (should be odd!)
       im2_pre = cv2.GaussianBlur(im2_pre, (offiltsize, offiltsize), 0) 
    elif ofwspre[ofimblur].value == 'Wiener':
       offiltsize = wb.get_named_range('OFFiltWinSizeBlur').attr_text[wb.get_named_range('OFFiltWinSizeBlur').attr_text.index('!$')+1::]
       offiltsize = int(ofwspre[offiltsize].value)
       im1_pre = signal.wiener(im1_pre, mysize = offiltsize)             # Wiener filtering, filtsize is size of the filter window (should be odd!)
       im2_pre = signal.wiener(im2_pre, mysize = offiltsize)    
       
    str1 = imlist[b]
    str2 = imlist[b+1]   
    cv2.imwrite(ImFold+'_pre/' + str1[0:-4] + '_OF_pre.png', im1_pre)    # Write preprocessed image 1 to created subfolder
    cv2.imwrite(ImFold+'_pre/' + str2[0:-4] + '_OF_pre.png', im2_pre)    # Write preprocessed image 2 to created subfolder

    return im1_pre, im2_pre   